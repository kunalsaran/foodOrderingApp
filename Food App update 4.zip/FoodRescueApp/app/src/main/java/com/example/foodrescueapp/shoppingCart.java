package com.example.foodrescueapp;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.foodrescueapp.databinding.ActivityShoppingCart2Binding;

public class shoppingCart extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityShoppingCart2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart2);

        binding = ActivityShoppingCart2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
    }
}