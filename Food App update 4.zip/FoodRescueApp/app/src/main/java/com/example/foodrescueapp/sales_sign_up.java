package com.example.foodrescueapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Patterns;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodrescueapp.data.DatabaseHelper;
import com.example.foodrescueapp.model.Sales;

public class sales_sign_up extends AppCompatActivity {
    DatabaseHelper db;

    EditText userName2;
    EditText email2;
    EditText phoneNo2;
    EditText address2;
    EditText password2;
    EditText confirmPassword2;
    Button saveButton2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sales_sign_up);
        userName2 = findViewById(R.id.userName2);
        email2 = findViewById(R.id.email2);
        phoneNo2 = findViewById(R.id.phoneNo2);
        address2 = findViewById(R.id.address2);
        password2 = findViewById(R.id.password2);
        confirmPassword2 = findViewById(R.id.confirmPassword2);
        saveButton2 = findViewById(R.id.saveButton2);

        db = new DatabaseHelper(sales_sign_up.this);

        saveButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password1234 = password2.getText().toString();
                String confirmPassword1234 = confirmPassword2.getText().toString();
                boolean doesSalesExist = db.doesSalesExist(userName2.getText().toString());
                boolean doesSalesEmailExist = db.doesSalesEmailExist(email2.getText().toString());

                if (userName2.getText().toString().isEmpty() || email2.getText().toString().isEmpty() || phoneNo2.getText().toString().isEmpty() || address2.getText().toString().isEmpty() || password2.getText().toString().isEmpty() || confirmPassword2.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please insert all fields.", Toast.LENGTH_SHORT).show();
                }
                else if (doesSalesExist){
                    Toast.makeText(getApplicationContext(), "Username already taken.", Toast.LENGTH_LONG).show();
                }
                else if (doesSalesEmailExist) {
                    Toast.makeText(getApplicationContext(), "Email already registered.", Toast.LENGTH_LONG).show();
                }
                else if (!Patterns.EMAIL_ADDRESS.matcher(email2.getText().toString()).matches()){
                    Toast.makeText(getApplicationContext(), "Please enter a valid Email.", Toast.LENGTH_LONG).show();
                }
                else if (password1234.equals(confirmPassword1234))
                {
                    Toast.makeText(getApplicationContext(),"SalesRep Signup Successful!",Toast.LENGTH_LONG).show();
                    long result = db.insertSales(new Sales(userName2.getText().toString(), password2.getText().toString(),email2.getText().toString(),phoneNo2.getText().toString(),address2.getText().toString()));
                    Intent MainActivity = new Intent(sales_sign_up.this, MainActivity.class);
                    startActivity(MainActivity);
                }
                else{
                    Toast.makeText(sales_sign_up.this,"Both provided passwords do not match",Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}