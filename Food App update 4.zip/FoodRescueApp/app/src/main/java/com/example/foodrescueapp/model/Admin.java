package com.example.foodrescueapp.model;

public class Admin {

    private int user_id1;
    private String username1;
    private String password1;
    private String email1;
    private String phoneNo1;
    private String address1;

    public Admin( String username1, String password1, String email1, String phoneNo1, String address1) {
        this.username1 = username1;
        this.password1 = password1;
        this.email1 = email1;
        this.phoneNo1 = phoneNo1;
        this.address1 = address1;
    }


    public Admin() {
    }

    public int getUser_id1() {
        return user_id1;
    }

    public void setUser_id1(int user_id1) {
        this.user_id1 = user_id1;
    }

    public String getUsername1() {
        return username1;
    }

    public void setUsername1(String username1) {
        this.username1 = username1;
    }

    public String getPassword1() {
        return password1;
    }

    public void setPassword1(String password1) {
        this.password1 = password1;
    }

    public String getEmail1(){
        return  email1;
    }

    public void setEmail1(String email1){
        this.email1 = email1;
    }

    public String getPhoneNo1(){
        return  phoneNo1;
    }

    public void setPhoneNo1(String phoneNo1){
        this.phoneNo1 = phoneNo1;
    }
    public String getAddress1(){
        return  address1;
    }

    public void setAddress1(String address1){
        this.address1 = address1;
    }
}