package com.example.foodrescueapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.foodrescueapp.data.DatabaseHelper;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

public class recyclerViewAdmin1 extends RecyclerView.Adapter<recyclerViewAdmin1.ViewHolder>
{

    private List<Food> foodList;
    private Context context;
    DatabaseHelper db;

    public recyclerViewAdmin1(List<Food> foodList, Context context)
    {
        this.foodList = foodList;
        this.context = context;
        db = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public recyclerViewAdmin1.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.recyclerviewshow1, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull recyclerViewAdmin1.ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.foodTitle.setText(foodList.get(position).getFood_title());
        holder.foodDescription.setText(foodList.get(position).getFood_desc());
        //holder.foodImage.setImageResource(foodList.get(position).getFood_imageID());
//        holder.foodImage.setImageURI(Uri.parse(foodList.get(position).getFood_imageID()));
        byte[] arraybyte = null;
        if (foodList.get(position).getFood_imageID() != null){
            arraybyte = foodList.get(position).getFood_imageID();
            Bitmap b = BitmapFactory.decodeByteArray(arraybyte,0,arraybyte.length);
            holder.foodImage.setImageBitmap(b);
        }
        /*byte[] finalArraybyte = arraybyte;
        holder.shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.insertSharedFood(new Food(foodList.get(position).getFood_title(),foodList.get(position).getFood_desc(), finalArraybyte));
                Intent myIntent = new Intent(Intent.ACTION_SEND);
                myIntent.setType("text/plain");
                String body = "Your body here";
                String sub = "Your Subject";
                myIntent.putExtra(Intent.EXTRA_SUBJECT,sub);
                myIntent.putExtra(Intent.EXTRA_TEXT,body);
                context.startActivity(Intent.createChooser(myIntent, "Share Using"));
            }
        });*/

    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView foodTitle;
        TextView foodDescription;
        ImageView foodImage;
        ImageButton shareButton;
        CardView foodCards;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            foodTitle = itemView.findViewById(R.id.foodTitle);
            foodDescription = itemView.findViewById(R.id.foodDescription);
            foodImage = itemView.findViewById(R.id.foodImage);
            shareButton = itemView.findViewById(R.id.shareButton);
            foodCards = itemView.findViewById(R.id.foodCards);
        }
    }
}