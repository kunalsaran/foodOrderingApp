package com.example.foodrescueapp.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.sqlite.SQLiteBlobTooBigException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.foodrescueapp.Food;
import com.example.foodrescueapp.model.Admin;
import com.example.foodrescueapp.model.Sales;
import com.example.foodrescueapp.model.User;
import com.example.foodrescueapp.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "tag";

    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_USER_TABLE = "CREATE TABLE " + Util.TABLE_NAME + "(" + Util.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.USERNAME + " TEXT , " + Util.PASSWORD + " TEXT , " + Util.EMAIL +" TEXT , " + Util.PHONENO +" TEXT , " + Util.ADDRESS + " TEXT)";
        String CREATE_ADMIN_TABLE = "CREATE TABLE " + Util.TABLE_NAME3 + "(" + Util.USER_ID1 + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.USERNAME1 + " TEXT , " + Util.PASSWORD1 + " TEXT , " + Util.EMAIL1 +" TEXT , " + Util.PHONENO1 +" TEXT , " + Util.ADDRESS1 + " TEXT)";
        String CREATE_SALES_TABLE = "CREATE TABLE " + Util.TABLE_NAME4 + "(" + Util.USER_ID2 + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.USERNAME2 + " TEXT , " + Util.PASSWORD2 + " TEXT , " + Util.EMAIL2 +" TEXT , " + Util.PHONENO2 +" TEXT , " + Util.ADDRESS2 + " TEXT)";
        String CREATE_FOOD_TABLE = "CREATE TABLE " + Util.TABLE_NAME1 + "(" + Util.FOOD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + Util.FOOD_TITLE + " TEXT , " + Util.FOOD_DESC + " TEXT , " + Util.FOOD_DATE +" TEXT , " + Util.FOOD_PCK_TIME +" TEXT , " + Util.FOOD_LOC +" TEXT , " + Util.FOOD_IMG + " BLOB , " + Util.FOOD_QNT + " TEXT)";
        String CREATE_SHAREDFOOD_TABLE = "CREATE TABLE " + Util.TABLE_NAME2 + "(" + Util.FOOD_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + Util.FOOD_TITLE + " TEXT , " + Util.FOOD_DESC + " TEXT , " + Util.FOOD_IMG + " BLOB)";
        sqLiteDatabase.execSQL(CREATE_USER_TABLE);
        sqLiteDatabase.execSQL(CREATE_FOOD_TABLE);
        sqLiteDatabase.execSQL(CREATE_SHAREDFOOD_TABLE);
        sqLiteDatabase.execSQL(CREATE_ADMIN_TABLE);
        sqLiteDatabase.execSQL(CREATE_SALES_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" +Util.TABLE_NAME+ "'");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" +Util.TABLE_NAME1+ "'");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" +Util.TABLE_NAME2+ "'");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" +Util.TABLE_NAME3+ "'");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" +Util.TABLE_NAME4+ "'");


        onCreate(sqLiteDatabase);

    }

    public long insertUser (User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.USERNAME, user.getUsername());
        contentValues.put(Util.PASSWORD, user.getPassword());
        contentValues.put(Util.EMAIL, user.getEmail());
        contentValues.put(Util.PHONENO, user.getPhoneNo());
        contentValues.put(Util.ADDRESS, user.getAddress());
        long newRowId = db.insert(Util.TABLE_NAME, null, contentValues);
        db.close();
        return newRowId;
    }

    public long insertAdmin (Admin admin)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.USERNAME1, admin.getUsername1());
        contentValues.put(Util.PASSWORD1, admin.getPassword1());
        contentValues.put(Util.EMAIL1, admin.getEmail1());
        contentValues.put(Util.PHONENO1, admin.getPhoneNo1());
        contentValues.put(Util.ADDRESS1, admin.getAddress1());
        long newRowId = db.insert(Util.TABLE_NAME3, null, contentValues);
        db.close();
        return newRowId;
    }

    public long insertSales (Sales sales)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.USERNAME2, sales.getUsername2());
        contentValues.put(Util.PASSWORD2, sales.getPassword2());
        contentValues.put(Util.EMAIL2, sales.getEmail2());
        contentValues.put(Util.PHONENO2, sales.getPhoneNo2());
        contentValues.put(Util.ADDRESS2, sales.getAddress2());
        long newRowId = db.insert(Util.TABLE_NAME4, null, contentValues);
        db.close();
        return newRowId;
    }



    public long insertFood (Food food)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.FOOD_TITLE, food.getFood_title());
        contentValues.put(Util.FOOD_DESC, food.getFood_desc());
        contentValues.put(Util.FOOD_DATE, food.getDate());
        contentValues.put(Util.FOOD_PCK_TIME, food.getPickup_times());
        contentValues.put(Util.FOOD_QNT, food.getQuantity());
        contentValues.put(Util.FOOD_LOC, food.getLocation());
        contentValues.put(Util.FOOD_IMG, food.getFood_imageID());
        long newRowId = db.insert(Util.TABLE_NAME1, null, contentValues);
        db.close();
        return newRowId;
    }

    public long insertSharedFood (Food food)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.FOOD_TITLE, food.getFood_title());
        contentValues.put(Util.FOOD_DESC, food.getFood_desc());
        contentValues.put(Util.FOOD_IMG, food.getFood_imageID());
        long newRowId = db.insert(Util.TABLE_NAME2, null, contentValues);
        db.close();
        return newRowId;
    }

    public boolean fetchUser(String username, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.USER_ID}, Util.USERNAME + "=? and " + Util.PASSWORD + "=?",
                new String[] {username, password}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public boolean fetchAdmin(String username1,String password1)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME3, new String[]{Util.USER_ID1}, Util.USERNAME1 + "=? and " + Util.PASSWORD1 + "=?",
                new String[] {username1, password1}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public boolean fetchSales(String username2,String password2)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME4, new String[]{Util.USER_ID2}, Util.USERNAME2 + "=? and " + Util.PASSWORD2 + "=?",
                new String[] {username2, password2}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public List<User> fetchAllUsers (){
        List<User> userList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
               // user.setUser_id(cursor.getInt(0));
                user.setUsername(cursor.getString(1));
               // user.setPassword(cursor.getString(2));

                userList.add(user);

            } while (cursor.moveToNext());

        }

        return userList;
    }

    public boolean doesUserExist(String username)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.USER_ID}, Util.USERNAME + "=?",
                new String[] {username}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public boolean doesAdminExist(String username1)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME3, new String[]{Util.USER_ID1}, Util.USERNAME1 + "=?",
                new String[] {username1}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public boolean doesSalesExist(String username2)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME4, new String[]{Util.USER_ID2}, Util.USERNAME2 + "=?",
                new String[] {username2}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public List<Admin> fetchAllAdmin (){
        List<Admin> adminList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME3;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst()) {
            do {
                Admin admin = new Admin();
                admin.setUser_id1(cursor.getInt(0));
                admin.setUsername1(cursor.getString(1));
                admin.setPassword1(cursor.getString(2));

                adminList.add(admin);

            } while (cursor.moveToNext());

        }

        return adminList;
    }

    public boolean doesUserEmailExist(String email)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.USER_ID}, Util.EMAIL + "=?",
                new String[] {email}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public boolean doesAdminEmailExist(String email1)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME3, new String[]{Util.USER_ID1}, Util.EMAIL1 + "=?",
                new String[] {email1}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public boolean doesSalesEmailExist(String email2)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME4, new String[]{Util.USER_ID2}, Util.EMAIL2 + "=?",
                new String[] {email2}, null, null, null);
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return  true;
        else
            return false;
    }

    public List<Sales> fetchAllSales (){
        List<Sales> salesList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME4;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst()) {
            do {
                Sales sales = new Sales();
                sales.setUser_id2(cursor.getInt(0));
                sales.setUsername2(cursor.getString(1));
                sales.setPassword2(cursor.getString(2));

                salesList.add(sales);

            } while (cursor.moveToNext());

        }

        return salesList;
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    public List<Food> fetchAllFoods (){
        List<Food> foodList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME1;
        Cursor cursor = db.rawQuery(selectAll, null);
        CursorWindow cw = new CursorWindow("test", 3197038);
        AbstractWindowedCursor ac = (AbstractWindowedCursor) cursor;
        ac.setWindow(cw);

        if (cursor.moveToFirst()) {
            do {
                Food food = new Food();
                food.setFood_title(cursor.getString(1));
                food.setFood_desc(cursor.getString(2));
                food.setFood_imageID(cursor.getBlob(6));
                food.setId(cursor.getInt(0));

                foodList.add(food);

            } while (cursor.moveToNext());

        }

        return foodList;
    }

    @RequiresApi(api = Build.VERSION_CODES.P)
    public List<Food> fetchAllSharedFoods (){
        List<Food> foodList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME2;
        Cursor cursor = db.rawQuery(selectAll, null);
        CursorWindow cw = new CursorWindow("test", 3197038);
        AbstractWindowedCursor ac = (AbstractWindowedCursor) cursor;
        ac.setWindow(cw);

        if (cursor.moveToFirst()) {
            do {
                Food food = new Food();
                food.setFood_title(cursor.getString(1));
                food.setFood_desc(cursor.getString(2));
                food.setFood_imageID(cursor.getBlob(3));
                food.setId(cursor.getInt(0));

                foodList.add(food);

            } while (cursor.moveToNext());

        }

        return foodList;
    }
}
