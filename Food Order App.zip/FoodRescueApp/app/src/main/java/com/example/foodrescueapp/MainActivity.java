package com.example.foodrescueapp;

import static com.example.foodrescueapp.R.id.signupButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodrescueapp.data.DatabaseHelper;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;

    EditText userNameInp;
    EditText passwordInp;
    Button loginButton;
    Button signupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userNameInp = findViewById(R.id.userNameInp);
        passwordInp = findViewById(R.id.passwordInp);
        loginButton = findViewById(R.id.loginButton);
        signupButton = findViewById(R.id.signupButton);
        db = new DatabaseHelper(this);



        loginButton.setOnClickListener(v -> {
            boolean result = db.fetchUser(userNameInp.getText().toString(), passwordInp.getText().toString());
            boolean result1 = db.fetchAdmin(userNameInp.getText().toString(), passwordInp.getText().toString());
            boolean result2 = db.fetchSales(userNameInp.getText().toString(), passwordInp.getText().toString());
            if (result) {
                Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                Intent homeIntent = new Intent(MainActivity.this, Home.class);
                startActivity(homeIntent);
            }
            else if (result1) {
                Toast.makeText(MainActivity.this,"Admin Login Successful!",Toast.LENGTH_SHORT).show();
                Intent adminHome = new Intent(MainActivity.this, AdminHomepage.class);
                startActivity(adminHome);
            }
            else if (result2) {
                Toast.makeText(MainActivity.this, "SalesRep Login Successful!", Toast.LENGTH_SHORT).show();
                Intent salesHome = new Intent(MainActivity.this, salesHomePage.class);
                startActivity(salesHome);
            }
            else if (userNameInp.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Please insert username",Toast.LENGTH_SHORT).show();
            }
            else if (passwordInp.getText().toString().isEmpty()){
                Toast.makeText(MainActivity.this,"Please insert password",Toast.LENGTH_SHORT).show();
            }
            else if (result == false || result1 == false || result2 == false ){
                Toast.makeText(MainActivity.this,"Incorrect Username/Password",Toast.LENGTH_SHORT).show();
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signUp = new Intent(MainActivity.this, signUp.class);
                startActivity(signUp);
            }
        });

    }
}