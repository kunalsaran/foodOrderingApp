package com.example.foodrescueapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.foodrescueapp.data.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class Home extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    DatabaseHelper db;
    Spinner Menu;
    ImageButton AddItem;
    RecyclerView foodRecyclerView;
    TextView homePageTitle;
    FoodRecyclerViewAdapter FoodRecyclerViewAdapter;
    FoodRecyclerViewAdapter FoodRecyclerViewAdapter1;
    List<Food> foodList = new ArrayList<>();
    List<Food> foodList1 = new ArrayList<>();

    String[] menuList ={"Home", "Account","My List"};
    String[] foodTitle = {"A fashion, food and entertainment destination", "Australia’s oldest train station"};
    String[] foodDesc = {"A fashion, food and entertainment destination for shoppers the world over.", "Flinders Street Station is Australia’s oldest train station, and with its prominent green copper dome."};
    int[] foodImageId = {R.drawable.add_circle,R.drawable.photo_camera};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        homePageTitle = findViewById(R.id.homePageTitle);
        Menu = findViewById(R.id.menuSelection);
        AddItem = findViewById(R.id.AddItem);
        foodRecyclerView =findViewById(R.id.foodRecyclerView);
        db = new DatabaseHelper(Home.this);
        Menu.setOnItemSelectedListener(this);


        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, menuList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Menu.setAdapter(adapter);

        AddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addItemIntent = new Intent(Home.this, AddFoodItem.class);
                startActivity(addItemIntent);
            }
        });


    }

    public void Foods(){
        FoodRecyclerViewAdapter = new FoodRecyclerViewAdapter(foodList1,this);
        foodRecyclerView.setAdapter(FoodRecyclerViewAdapter);

        foodRecyclerView.setLayoutManager(new LinearLayoutManager(this));


        List<Food> foodList = db.fetchAllFoods();
        for (Food food :foodList)
        {
            Food food1 = new Food(food.food_title, food.food_desc, food.food_imageID, food.id);
            foodList1.add(food1);
        }
    }

    public void Foods1(){
        FoodRecyclerViewAdapter1 = new FoodRecyclerViewAdapter(foodList,this);
        foodRecyclerView.setAdapter(FoodRecyclerViewAdapter1);

        foodRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Food> foodList1 = db.fetchAllSharedFoods();
        for (Food food :foodList1)
        {
            Food food1 = new Food(food.food_title, food.food_desc, food.food_imageID, food.id);
            foodList.add(food1);
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String selectedItem = Menu.getSelectedItem().toString();
        if (selectedItem.equals(menuList[2])){
            homePageTitle.setText("");
            foodList = new ArrayList<>();
            Foods1();
        }
        else if (selectedItem.equals(menuList[0])){
            homePageTitle.setText("Discover free food");
            foodList1 = new ArrayList<>();
            Foods();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}