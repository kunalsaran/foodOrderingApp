package com.example.foodrescueapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Patterns;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodrescueapp.data.DatabaseHelper;
import com.example.foodrescueapp.model.Admin;

public class adminSign_up extends AppCompatActivity {
    DatabaseHelper db;

    EditText userName1;
    EditText email1;
    EditText phoneNo1;
    EditText address1;
    EditText password1;
    EditText confirmPassword1;
    Button saveButton1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_sign_up);
        userName1 = findViewById(R.id.userName1);
        email1 = findViewById(R.id.email1);
        phoneNo1 = findViewById(R.id.phoneNo1);
        address1 = findViewById(R.id.address1);
        password1 = findViewById(R.id.password1);
        confirmPassword1 = findViewById(R.id.confirmPassword1);
        saveButton1 = findViewById(R.id.saveButton1);

        db = new DatabaseHelper(adminSign_up.this);

        saveButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password123 = password1.getText().toString();
                String confirmPassword123 = confirmPassword1.getText().toString();
                boolean doesAdminExist = db.doesAdminExist(userName1.getText().toString());
                boolean doesAdminEmailExist = db.doesAdminEmailExist(email1.getText().toString());

                if (userName1.getText().toString().isEmpty() || email1.getText().toString().isEmpty() || phoneNo1.getText().toString().isEmpty() || address1.getText().toString().isEmpty() || password1.getText().toString().isEmpty() || confirmPassword1.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please insert all fields.", Toast.LENGTH_SHORT).show();
                }
                else if (doesAdminExist){
                    Toast.makeText(getApplicationContext(), "Username already taken.", Toast.LENGTH_LONG).show();
                }
                else if (doesAdminEmailExist) {
                    Toast.makeText(getApplicationContext(), "Email already registered.", Toast.LENGTH_LONG).show();
                }
                else if (!Patterns.EMAIL_ADDRESS.matcher(email1.getText().toString()).matches()){
                    Toast.makeText(getApplicationContext(), "Please enter a valid Email.", Toast.LENGTH_LONG).show();
                }
                else if ((password123.equals(confirmPassword123)))
                {
                    Toast.makeText(getApplicationContext(),"Admin Signup Successful!",Toast.LENGTH_LONG).show();
                    long result = db.insertAdmin(new Admin(userName1.getText().toString(), password1.getText().toString(),email1.getText().toString(),phoneNo1.getText().toString(),address1.getText().toString()));
                    Intent MainActivity = new Intent(adminSign_up.this, MainActivity.class);
                    startActivity(MainActivity);
                }
                else{
                    Toast.makeText(adminSign_up.this,"Both provided passwords do not match",Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}